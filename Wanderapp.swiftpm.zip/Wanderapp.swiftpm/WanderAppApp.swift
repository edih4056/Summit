//
//  WanderAppApp.swift
//  WanderApp
//
//  Created by Edi Delic on 11.07.2026.
//

import SwiftUI

@main
struct WanderAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
