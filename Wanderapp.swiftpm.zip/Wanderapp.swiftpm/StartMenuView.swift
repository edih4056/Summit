import SwiftUI

struct StartMenuView: View {
    let onStart: () -> Void

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color.black.opacity(0.9), Color.blue.opacity(0.7)],
                           startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()

            VStack(spacing: 1) {
                Spacer()

                Text("Willkommen bei Summit")
                    .font(.title)
                    .bold()
                    .foregroundColor(.white)

                Spacer()

                Button {
                    onStart()
                } label: {
                    Label("Zur Karte", systemImage: "map.fill")
                        .bold()
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.white)
                        .foregroundColor(.black)
                        .cornerRadius(12)
                }
                .padding(.horizontal, 34)
                .padding(.bottom, 40)
            }
        }
    }
}
