//
//  ContentView.swift
//  WanderApp
//
//  Created by Edi Delic on 11.07.2026.
//

import SwiftUI
import MapKit
import UniformTypeIdentifiers

struct ContentView: View {
    @StateObject private var locationManager = LocationManager()
    @StateObject private var viewModel = RouteViewModel()
    @State private var showImporter = false
    @State private var showChart = false
    @State private var showLibrary = false
    @State private var showStartMenu = true
    @State private var isNavigating = false

    private var currentHeading: Double {
        guard let previous = locationManager.previousLocation,
              let current = locationManager.lastLocation else { return 0 }
        return GeoMath.bearing(lat1: previous.coordinate.latitude,
                               lon1: previous.coordinate.longitude,
                               lat2: current.coordinate.latitude,
                               lon2: current.coordinate.longitude)
    }

    var body: some View {
        if showStartMenu {
            StartMenuView {
                showStartMenu = false
                showLibrary = true
            }
            .onAppear { locationManager.requestPermission() }
        } else {
            mapScreen
        }
    }

    private var mapScreen: some View {
        ZStack(alignment: .bottom) {
            RouteMapView(points: viewModel.points,
                         isNavigating: isNavigating,
                         userLocation: locationManager.lastLocation,
                         heading: currentHeading,
                         selectedPoint: viewModel.selectedPoint)
                .ignoresSafeArea()

            VStack(spacing: 12) {
                if isNavigating {
                    Button {
                        isNavigating = false
                    } label: {
                        Label("Navigation beenden", systemImage: "xmark.circle")
                            .bold()
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.red)
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }
                } else {
                    if !viewModel.points.isEmpty {
                        HStack {
                            StatBox(title: "Distanz",
                                    value: String(format: "%.1f km", viewModel.distance / 1000))
                            StatBox(title: "Aufstieg",
                                    value: String(format: "%.0f m", viewModel.ascent))
                            StatBox(title: "Abstieg",
                                    value: String(format: "%.0f m", viewModel.descent))
                        }

                        Button("Höhenprofil anzeigen") {
                            showChart = true
                        }

                        Button {
                            isNavigating = true
                        } label: {
                            Label("Route starten", systemImage: "location.north.line")
                                .bold()
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.orange)
                                .foregroundColor(.white)
                                .cornerRadius(12)
                        }
                    }

                    Button {
                        showLibrary = true
                    } label: {
                        Label("Routen-Bibliothek", systemImage: "books.vertical")
                            .bold()
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }

                    Button {
                        showImporter = true
                    } label: {
                        Label("GPX importieren", systemImage: "square.and.arrow.down")
                            .bold()
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }
                }
            }
            .padding(16)
            .background(.ultraThinMaterial)
            .cornerRadius(20)
            .padding()
        }
        .overlay(alignment: .top) {
            if isNavigating {
                SlopeBarView(gradient: viewModel.expectedGradient(at: locationManager.lastLocation))
                    .padding(.top, 8)
            }
        }
        .fileImporter(
            isPresented: $showImporter,
            allowedContentTypes: [UTType(filenameExtension: "gpx") ?? .xml]
        ) { result in
            switch result {
            case .success(let url):
                viewModel.importGPX(from: url)
            case .failure(let error):
                viewModel.errorMessage = error.localizedDescription
            }
        }
        .alert("Fehler", isPresented: .constant(viewModel.errorMessage != nil)) {
            Button("OK") { viewModel.errorMessage = nil }
        } message: {
            Text(viewModel.errorMessage ?? "")
        }
        .sheet(isPresented: $showChart, onDismiss: { viewModel.selectedPoint = nil }) {
            ElevationChartView(points: viewModel.points,
                               selection: $viewModel.selectedPoint)
                .presentationDetents([.medium, .large])
        }
        .sheet(isPresented: $showLibrary) {
            RouteLibraryView(
                userLocation: locationManager.lastLocation,
                onSelect: { route in
                    viewModel.loadLibraryRoute(route)
                    showLibrary = false
                },
                onImport: {
                    showLibrary = false
                    showImporter = true
                }
            )
        }
    }

}

struct SlopeBarView: View {
    let gradient: Double?

    var body: some View {
        HStack(spacing: 8) {
            if let gradient {
                if gradient > 2 {
                    Image(systemName: "arrow.up.right")
                        .foregroundColor(.red)
                    Text(String(format: "Steigung %.0f %%", gradient))
                } else if gradient < -2 {
                    Image(systemName: "arrow.down.right")
                        .foregroundColor(.blue)
                    Text(String(format: "Gefälle %.0f %%", abs(gradient)))
                } else {
                    Image(systemName: "arrow.right")
                        .foregroundColor(.secondary)
                    Text("Eben")
                }
            } else {
                Image(systemName: "location.slash")
                    .foregroundColor(.secondary)
                Text("Keine Steigungsdaten")
            }
        }
        .font(.headline)
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(.ultraThinMaterial)
        .cornerRadius(12)
    }
}

struct StatBox: View {
    let title: String
    let value: String

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
            Text(value)
                .font(.title3)
                .bold()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10)
        .background(Color.white.opacity(0.5))
        .cornerRadius(10)
    }
}


#Preview {
    ContentView()
}
