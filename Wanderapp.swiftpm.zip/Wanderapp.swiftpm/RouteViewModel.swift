//
//  RouteViewModel.swift
//  WanderApp
//
//  Created by Edi Delic on 11.07.2026.
//

import Foundation
import Combine
import CoreLocation

@MainActor
final class RouteViewModel: ObservableObject {
 
    @Published var points: [TrackPoint] = []
    @Published var distance: Double = 0
    @Published var ascent: Double = 0
    @Published var descent: Double = 0
    @Published var errorMessage: String?
    @Published var selectedPoint: TrackPoint?
 
    func importGPX(from url: URL) {
        
        let hasAccess = url.startAccessingSecurityScopedResource()
        defer { if hasAccess { url.stopAccessingSecurityScopedResource() } }
 
        guard let parsed = GPXParser().parse(url: url), !parsed.isEmpty else {
            errorMessage = "Die Datei konnte nicht gelesen werden oder enthält keine Trackpunkte."
            return
        }
        points = parsed
        print("GPX geladen: \(parsed.count) Punkte")
        recalculate()
    }

    func loadLibraryRoute(_ route: SavedRoute) {
        guard let url = Bundle.main.url(forResource: route.fileName, withExtension: "gpx") else {
            errorMessage = "Die Route \(route.name) wurde nicht im App-Paket gefunden."
            return
        }
        guard let parsed = GPXParser().parse(url: url), !parsed.isEmpty else {
            errorMessage = "Die Datei konnte nicht gelesen werden oder enthält keine Trackpunkte."
            return
        }
        points = parsed
        recalculate()
    }

    func expectedGradient(at location: CLLocation?) -> Double? {
        guard let location, points.count > 1 else { return nil }

        var nearestIndex = 0
        var nearestDistance = Double.greatestFiniteMagnitude
        for i in 0..<points.count {
            let d = GeoMath.haversine(lat1: location.coordinate.latitude,
                                      lon1: location.coordinate.longitude,
                                      lat2: points[i].lat,
                                      lon2: points[i].lon)
            if d < nearestDistance {
                nearestDistance = d
                nearestIndex = i
            }
        }
        guard nearestDistance < 200 else { return nil }

        var walked = 0.0
        var j = nearestIndex
        while j < points.count - 1 && walked < 200 {
            walked += GeoMath.haversine(lat1: points[j].lat, lon1: points[j].lon,
                                        lat2: points[j+1].lat, lon2: points[j+1].lon)
            j += 1
        }
        guard walked > 0 else { return nil }

        let elevationChange = points[j].ele - points[nearestIndex].ele
        return elevationChange / walked * 100
    }

    private func recalculate() {
        distance = GeoMath.totalDistance(points)
        let smoothed = GeoMath.smoothedElevations(points)
        ascent = GeoMath.ascent(smoothed)
        descent = GeoMath.descent(smoothed)
    }
}

