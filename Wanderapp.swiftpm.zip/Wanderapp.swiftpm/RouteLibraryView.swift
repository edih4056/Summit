import SwiftUI
import CoreLocation

struct RouteLibraryView: View {
    let userLocation: CLLocation?
    let onSelect: (SavedRoute) -> Void
    let onImport: () -> Void

    private var sortedRoutes: [SavedRoute] {
        guard let location = userLocation else {
            return RouteLibrary.routes
        }
        return RouteLibrary.routes.sorted { first, second in
            distanceToStart(of: first, from: location) < distanceToStart(of: second, from: location)
        }
    }

    private func distanceToStart(of route: SavedRoute, from location: CLLocation) -> Double {
        GeoMath.haversine(lat1: location.coordinate.latitude,
                          lon1: location.coordinate.longitude,
                          lat2: route.startLat,
                          lon2: route.startLon)
    }

    private func distanceText(for route: SavedRoute) -> String? {
        guard let location = userLocation else { return nil }
        let meters = distanceToStart(of: route, from: location)
        return String(format: "%.1f km von deinem Standort entfernt", meters / 1000)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 12) {
                    Button {
                        onImport()
                    } label: {
                        Label("Eigene GPX-Datei importieren", systemImage: "square.and.arrow.down")
                            .bold()
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }

                    ForEach(sortedRoutes) { route in
                        Button {
                            onSelect(route)
                        } label: {
                            RouteCard(route: route, distanceText: distanceText(for: route))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding()
            }
            .navigationTitle("Willkommen")
        }
    }
}

struct RouteCard: View {
    let route: SavedRoute
    let distanceText: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(route.name)
                .font(.headline)
            Text(route.region)
                .font(.subheadline)
                .foregroundColor(.secondary)
            HStack(spacing: 16) {
                Label(String(format: "%.1f km", route.distanceKm), systemImage: "map")
                Label(String(format: "%.0f m", route.ascent), systemImage: "arrow.up.right")
            }
            .font(.subheadline)
            if let distanceText {
                Text(distanceText)
                    .font(.caption)
                    .foregroundColor(.blue)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color(.secondarySystemBackground))
        .cornerRadius(12)
    }
}
