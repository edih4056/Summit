import SwiftUI
import Charts


struct ProfilePoint: Identifiable {
    let id = UUID()
    let index: Int
    let distanceKm: Double
    let elevation: Double
}

struct ElevationChartView: View {
    let points: [TrackPoint]
    @Binding var selection: TrackPoint?

    @State private var selectedProfilePoint: ProfilePoint?

    private var profile: [ProfilePoint] {
        let smoothed = GeoMath.smoothedElevations(points)
        var result: [ProfilePoint] = []
        var distanceSoFar = 0.0

        for i in 0..<points.count {
            if i > 0 {
                distanceSoFar += GeoMath.haversine(
                    lat1: points[i-1].lat, lon1: points[i-1].lon,
                    lat2: points[i].lat,   lon2: points[i].lon)
            }
            result.append(ProfilePoint(index: i,
                                       distanceKm: distanceSoFar / 1000,
                                       elevation: smoothed[i]))
        }
        return result
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Höhenprofil")
                .font(.headline)

            if let selected = selectedProfilePoint {
                Text(String(format: "Kilometer %.2f: %.0f m ü. M.", selected.distanceKm, selected.elevation))
                    .font(.subheadline)
                    .bold()
                    .foregroundColor(.orange)
            } else {
                Text("Fahre mit dem Finger über das Diagramm, um Höhenwerte abzulesen.")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }

            Chart {
                ForEach(profile) { point in
                    AreaMark(
                        x: .value("Distanz (km)", point.distanceKm),
                        y: .value("Höhe (m)", point.elevation)
                    )
                    .foregroundStyle(
                        .linearGradient(colors: [.green.opacity(0.5), .green.opacity(0.05)],
                                        startPoint: .top, endPoint: .bottom)
                    )

                    LineMark(
                        x: .value("Distanz (km)", point.distanceKm),
                        y: .value("Höhe (m)", point.elevation)
                    )
                    .foregroundStyle(.green)
                }

                if let selected = selectedProfilePoint {
                    RuleMark(x: .value("Distanz (km)", selected.distanceKm))
                        .foregroundStyle(.orange)

                    PointMark(
                        x: .value("Distanz (km)", selected.distanceKm),
                        y: .value("Höhe (m)", selected.elevation)
                    )
                    .foregroundStyle(.orange)
                    .symbolSize(120)
                }
            }
            .chartYScale(domain: .automatic(includesZero: false))
            .chartXAxisLabel("Distanz (km)")
            .chartYAxisLabel("Höhe (m)")
            .chartOverlay { proxy in
                GeometryReader { geometry in
                    Rectangle()
                        .fill(Color.clear)
                        .contentShape(Rectangle())
                        .gesture(
                            DragGesture(minimumDistance: 0)
                                .onChanged { value in
                                    updateSelection(at: value.location, proxy: proxy, geometry: geometry)
                                }
                                .onEnded { _ in
                                    selectedProfilePoint = nil
                                    selection = nil
                                }
                        )
                }
            }
        }
        .padding()
    }

    private func updateSelection(at location: CGPoint, proxy: ChartProxy, geometry: GeometryProxy) {
        guard let plotFrame = proxy.plotFrame else { return }
        let xInPlot = location.x - geometry[plotFrame].origin.x
        guard let distance: Double = proxy.value(atX: xInPlot) else { return }

        guard var nearest = profile.first else { return }
        for point in profile {
            if abs(point.distanceKm - distance) < abs(nearest.distanceKm - distance) {
                nearest = point
            }
        }
        selectedProfilePoint = nearest
        selection = points[nearest.index]
    }
}
