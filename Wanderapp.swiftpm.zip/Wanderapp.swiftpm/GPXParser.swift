//
//  GPXParser.swift
//  WanderApp
//
//  Created by Edi Delic on 11.07.2026.
//

import Foundation

final class GPXParser: NSObject, XMLParserDelegate {
    private var points: [TrackPoint] = []
    private var currentLat: Double?
    private var currentLon: Double?
    private var currentEle: Double = 0.0
    private var currentText = ""
    private var insideTrackPoint = false

    func parse(url: URL) -> [TrackPoint]? {
        guard let parser = XMLParser(contentsOf: url) else { return nil}
        parser.delegate = self
        points = []
        let success = parser.parse()
        return success ? points : nil
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String,
                    namespaceURI: String?, qualifiedName qName: String?,
                    attributes attributeDict: [String: String] = [:]) {
            if elementName == "trkpt" {
                insideTrackPoint = true
                currentLat = Double(attributeDict["lat"] ?? "")
                currentLon = Double(attributeDict["lon"] ?? "")
                currentEle = 0
            }
            currentText = ""
        }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
            currentText += string
        }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String,
                    namespaceURI: String?, qualifiedName qName: String?) {
            if elementName == "ele" && insideTrackPoint {
                let cleaned = currentText.trimmingCharacters(in: .whitespacesAndNewlines)
                currentEle = Double(cleaned) ?? 0
            }
            if elementName == "trkpt" {
                insideTrackPoint = false
                if let lat = currentLat, let lon = currentLon {
                    points.append(TrackPoint(lat: lat, lon: lon, ele: currentEle))
                }
            }
        }
}
