import Foundation

struct SavedRoute: Identifiable {
    let id = UUID()
    let name: String
    let region: String
    let fileName: String
    let distanceKm: Double
    let ascent: Double
    let startLat: Double
    let startLon: Double
}

enum RouteLibrary {
    static let routes: [SavedRoute] = [
        SavedRoute(name: "Uetliberg – Felsenegg", region: "Zürich", fileName: "uetliberg_felsenegg", distanceKm: 5.3, ascent: 90, startLat: 47.3497, startLon: 8.4913),
        SavedRoute(name: "Greifensee-Uferweg", region: "Zürcher Oberland", fileName: "greifensee_uferweg", distanceKm: 7.3, ascent: 10, startLat: 47.3389, startLon: 8.6674),
        SavedRoute(name: "Rigi Panoramaweg", region: "Zentralschweiz", fileName: "rigi_panoramaweg", distanceKm: 7.1, ascent: 330, startLat: 47.0407, startLon: 8.4655),
        SavedRoute(name: "Männlichen – Kleine Scheidegg", region: "Berner Oberland", fileName: "maennlichen_scheidegg", distanceKm: 4.5, ascent: 28, startLat: 46.6110, startLon: 7.9426),
        SavedRoute(name: "Pfannenstiel-Rundweg", region: "Zürichsee", fileName: "pfannenstiel_runde", distanceKm: 12.8, ascent: 426, startLat: 47.2900, startLon: 8.6463),
    ]
}
