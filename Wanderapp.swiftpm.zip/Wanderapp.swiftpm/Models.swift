//
//  Models.swift
//  WanderApp
//
//  Created by Edi Delic on 11.07.2026.
//

import Foundation

struct TrackPoint: Identifiable {
    let id = UUID()
    let lat: Double
    let lon: Double
    let ele: Double
}
