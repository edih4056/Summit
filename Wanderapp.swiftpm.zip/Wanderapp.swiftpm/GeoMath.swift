//
//  GeoMath.swift
//  WanderApp
//
//  Created by Edi Delic on 11.07.2026.
//

import Foundation
 

enum GeoMath {
 
    static let earthRadius = 6_371_000.0
    static func haversine(lat1: Double, lon1: Double, lat2: Double, lon2: Double) -> Double {
        let phi1 = lat1 * .pi / 180
        let phi2 = lat2 * .pi / 180
        let dPhi = (lat2 - lat1) * .pi / 180
        let dLambda = (lon2 - lon1) * .pi / 180
 
        let a = sin(dPhi / 2) * sin(dPhi / 2)
              + cos(phi1) * cos(phi2) * sin(dLambda / 2) * sin(dLambda / 2)
 
        return 2 * earthRadius * asin(sqrt(a)) 
    }

    static func bearing(lat1: Double, lon1: Double, lat2: Double, lon2: Double) -> Double {
        let phi1 = lat1 * .pi / 180
        let phi2 = lat2 * .pi / 180
        let dLambda = (lon2 - lon1) * .pi / 180

        let y = sin(dLambda) * cos(phi2)
        let x = cos(phi1) * sin(phi2) - sin(phi1) * cos(phi2) * cos(dLambda)

        var degrees = atan2(y, x) * 180 / .pi
        if degrees < 0 {
            degrees += 360
        }
        return degrees
    }

    static func totalDistance(_ points: [TrackPoint]) -> Double {
        guard points.count > 1 else { return 0 }
        var total = 0.0
        for i in 0..<points.count - 1 {
            total += haversine(lat1: points[i].lat,   lon1: points[i].lon,
                               lat2: points[i+1].lat, lon2: points[i+1].lon)
        }
        return total
    }
    static func smoothedElevations(_ points: [TrackPoint], window: Int = 5) -> [Double] {
        let elevations = points.map { $0.ele }
        guard elevations.count > window else { return elevations }
 
        let half = window / 2
        var result: [Double] = []
        for i in 0..<elevations.count {
            let lower = max(0, i - half)
            let upper = min(elevations.count - 1, i + half)
            let slice = elevations[lower...upper]
            result.append(slice.reduce(0, +) / Double(slice.count))
        }
        return result
    }
    static func ascent(_ elevations: [Double]) -> Double {
        guard elevations.count > 1 else { return 0 }
        var total = 0.0
        for i in 0..<elevations.count - 1 {
            let diff = elevations[i+1] - elevations[i]
            if diff > 0 { total += diff }
        }
        return total
    }
    static func descent(_ elevations: [Double]) -> Double {
        guard elevations.count > 1 else { return 0 }
        var total = 0.0
        for i in 0..<elevations.count - 1 {
            let diff = elevations[i] - elevations[i+1]
            if diff > 0 { total += diff }
        }
        return total
    }
}

