//
//  RouteMapView.swift
//  WanderApp
//
//  Created by Edi Delic on 11.07.2026.
//
import SwiftUI
import MapKit
import CoreLocation

struct RouteMapView: UIViewRepresentable {
    let points: [TrackPoint]
    let isNavigating: Bool
    let userLocation: CLLocation?
    let heading: Double
    let selectedPoint: TrackPoint?

    func makeUIView(context: Context) -> MKMapView {
        let map = MKMapView()
        map.delegate = context.coordinator
        map.showsUserLocation = true
        map.showsCompass = false // eigener Kompass unter der Button-Leiste

        context.coordinator.mapView = map
        context.coordinator.addControls(to: map)
        return map
    }

    func updateUIView(_ map: MKMapView, context: Context) {
        let coordinator = context.coordinator
        let routeKey = "\(points.count)-\(points.first?.lat ?? 0)-\(points.first?.lon ?? 0)"
        let routeChanged = routeKey != coordinator.lastRouteKey

        if routeChanged {
            coordinator.lastRouteKey = routeKey
            map.removeOverlays(map.overlays)
            map.removeAnnotations(map.annotations.filter { !($0 is MKUserLocation) })

            if points.count > 1 {
                let coords = points.map { CLLocationCoordinate2D(latitude: $0.lat, longitude: $0.lon) }
                let polyline = MKPolyline(coordinates: coords, count: coords.count)
                map.addOverlay(polyline)

                let start = MKPointAnnotation()
                start.coordinate = coords.first!
                start.title = "Start"
                let end = MKPointAnnotation()
                end.coordinate = coords.last!
                end.title = "Ziel"
                map.addAnnotations([start, end])
            }
        }
        
        coordinator.trackingButton?.isHidden = isNavigating

        if isNavigating {
            if map.userTrackingMode != .none {
                map.setUserTrackingMode(.none, animated: false)
            }
            map.mapType = coordinator.chosenMapType ?? .hybridFlyover
            if let location = userLocation {
                let camera = MKMapCamera(lookingAtCenter: location.coordinate,
                                         fromDistance: coordinator.is3D ? 600 : 900,
                                         pitch: coordinator.is3D ? 60 : 0,
                                         heading: coordinator.is3D ? heading : 0)
                map.setCamera(camera, animated: true)
            }
        } else {
            map.mapType = coordinator.chosenMapType ?? .standard
            let cameBackFrom3D = coordinator.wasNavigating

            if cameBackFrom3D {
                let flatCamera = map.camera
                flatCamera.pitch = 0
                flatCamera.heading = 0
                map.setCamera(flatCamera, animated: false)
            }

            if routeChanged || cameBackFrom3D {
                if let polyline = map.overlays.first as? MKPolyline {
                    map.setVisibleMapRect(
                        polyline.boundingMapRect,
                        edgePadding: UIEdgeInsets(top: 80, left: 40, bottom: 260, right: 40),
                        animated: true
                    )
                }
            }
        }
        coordinator.wasNavigating = isNavigating

        let marker = coordinator.selectionMarker
        map.removeAnnotation(marker)
        if let selected = selectedPoint {
            marker.coordinate = CLLocationCoordinate2D(latitude: selected.lat, longitude: selected.lon)
            marker.title = "Ausgewählt"
            map.addAnnotation(marker) //i call it a day
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    @MainActor
    final class Coordinator: NSObject, MKMapViewDelegate {
        var lastRouteKey = ""
        var wasNavigating = false
        let selectionMarker = MKPointAnnotation()

        weak var mapView: MKMapView?
        var chosenMapType: MKMapType?
        var is3D = true
        var trackingButton: MKUserTrackingButton?
        private let styleButton = UIButton(type: .system)

        func addControls(to map: MKMapView) {
            let tracking = MKUserTrackingButton(mapView: map)
            trackingButton = tracking

            var config = UIButton.Configuration.plain()
            config.image = UIImage(systemName: "map")
            styleButton.configuration = config
            styleButton.showsMenuAsPrimaryAction = true
            styleButton.menu = makeStyleMenu()

            let stack = UIStackView(arrangedSubviews: [tracking, styleButton])
            stack.axis = .vertical
            stack.backgroundColor = UIColor.systemBackground.withAlphaComponent(0.9)
            stack.layer.cornerRadius = 10
            stack.clipsToBounds = true
            stack.translatesAutoresizingMaskIntoConstraints = false
            map.addSubview(stack)

            let compass = MKCompassButton(mapView: map)
            compass.compassVisibility = .adaptive
            compass.translatesAutoresizingMaskIntoConstraints = false
            map.addSubview(compass) // nie meh swift die ns

            let guide = map.safeAreaLayoutGuide
            NSLayoutConstraint.activate([
                stack.topAnchor.constraint(equalTo: guide.topAnchor, constant: 10),
                stack.trailingAnchor.constraint(equalTo: guide.trailingAnchor, constant: -10),
                stack.widthAnchor.constraint(equalToConstant: 44),
                tracking.heightAnchor.constraint(equalToConstant: 44),
                styleButton.heightAnchor.constraint(equalToConstant: 44),
                compass.topAnchor.constraint(equalTo: stack.bottomAnchor, constant: 10),
                compass.centerXAnchor.constraint(equalTo: stack.centerXAnchor)
            ])
        }

        private func makeStyleMenu() -> UIMenu {
            let options: [(title: String, icon: String, type: MKMapType?)] = [
                ("Karte", "map", .standard),
                ("Satellit", "globe.europe.africa", .satelliteFlyover),
            ]
            let actions = options.map { option in
                UIAction(title: option.title,
                         image: UIImage(systemName: option.icon),
                         state: option.type == chosenMapType ? .on : .off) { [weak self] _ in
                    self?.selectMapType(option.type)
                }
            }
            let perspective = UIMenu(title: "Perspektive", options: .displayInline, children: [
                UIAction(title: "2D", image: UIImage(systemName: "square"),
                         state: is3D ? .off : .on) { [weak self] _ in self?.setPerspective(is3D: false) },
                UIAction(title: "3D", image: UIImage(systemName: "cube"),
                         state: is3D ? .on : .off) { [weak self] _ in self?.setPerspective(is3D: true) },
            ])
            return UIMenu(title: "Kartenansicht", children: actions + [perspective])
        }

        private func selectMapType(_ type: MKMapType?) {
            chosenMapType = type
            styleButton.menu = makeStyleMenu()
            mapView?.mapType = type ?? (wasNavigating ? .hybridFlyover : .standard)
        }
        
        private func setPerspective(is3D: Bool) {
            self.is3D = is3D
            styleButton.menu = makeStyleMenu()
            guard let map = mapView, !is3D else { return }
            let flat = map.camera
            flat.pitch = 0
            flat.heading = 0
            map.setCamera(flat, animated: true)
        }

        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let polyline = overlay as? MKPolyline {
                let renderer = MKPolylineRenderer(polyline: polyline)
                renderer.strokeColor = .systemRed
                renderer.lineWidth = 4
                return renderer
            }
            return MKOverlayRenderer(overlay: overlay)
        }

        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            guard !(annotation is MKUserLocation) else { return nil }
            let id = "pin"
            let view = mapView.dequeueReusableAnnotationView(withIdentifier: id) as? MKMarkerAnnotationView
                ?? MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: id)
            view.annotation = annotation
            if annotation.title == "Start" {
                view.markerTintColor = .systemGreen
            } else if annotation.title == "Ziel" {
                view.markerTintColor = .systemRed
            } else {
                view.markerTintColor = .systemOrange
            }
            return view
        }
    }
}
