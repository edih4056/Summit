//
//  LocationManager.swift
//  WanderApp
//
//  Created by Edi Delic on 11.07.2026.
//

import Foundation
import CoreLocation
import Combine

final class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    private let manager = CLLocationManager()
    @Published var lastLocation: CLLocation?
    @Published var previousLocation: CLLocation?

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
    }

    func requestPermission() {
        manager.requestWhenInUseAuthorization()
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if manager.authorizationStatus == .authorizedWhenInUse {
            manager.startUpdatingLocation()
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let newLocation = locations.last else { return }

        if let current = lastLocation {
            let moved = GeoMath.haversine(lat1: current.coordinate.latitude,
                                          lon1: current.coordinate.longitude,
                                          lat2: newLocation.coordinate.latitude,
                                          lon2: newLocation.coordinate.longitude)
            if moved < 5 {
                return
            }
            previousLocation = current
        }
        lastLocation = newLocation
    }
}
